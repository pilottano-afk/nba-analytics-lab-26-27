# NBA + LBA Basketball Analytics — prototype v12.0

Prototipo per la stagione **2026/27**, focalizzato esclusivamente su Serie A LBA e Serie A2 Old Wild West. Riutilizza la base tecnica del precedente Euro Basketball Stats Hub: Next.js 15 / React 19, FastAPI, PostgreSQL, Redis e pipeline di validazione/checksum.

## Cosa funziona in questa versione
- Dashboard responsive in italiano con selettore LBA / A2.
- Leaderboard separati per competizione e profili giocatore demo.
- Shot Selection Studio con filtri per quarto, esito e clutch.
- API `/api/v1/competitions`, `/api/v1/leaderboards`, `/api/v1/players/{id}`, `/api/v1/players/{id}/shot-chart`.
- Directory fonti ufficiali in `/api/v1/sources` e controllo HTTP in `/api/v1/sources/check`.
- Task Celery notturno alle 02:00 UTC che verifica solo la raggiungibilità delle fonti; non importa statistiche sintetiche nel database canonico.
- Schema PostgreSQL e seed con competizioni e club di esempio.

## Importante: dati reali vs demo
Tutti i profili, i valori statistici e i tiri mostrati nella dashboard sono **fixture sintetiche** usate per testare l'interfaccia e le API. Le fonti ufficiali LBA e LNP sono collegate e la raggiungibilità può essere verificata, ma questa versione **non estrae né importa automaticamente tabellini ufficiali**. Prima dell'import serve verificare stabilità, formato e condizioni di riutilizzo dei dati.

Fonti ufficiali collegate:
- LBA: https://www.legabasket.it/calendario/1/serie-a
- Serie A2 LNP: https://www.legapallacanestro.com/serie/1/calendario
- LNP PASS: https://lnppass.legapallacanestro.com/?lang=it

## Avvio locale
```bash
docker compose up --build
```
- Dashboard: http://localhost:3000
- API health: http://localhost:8000/health
- API docs: http://localhost:8000/docs

## Test backend
```bash
cd apps/api
pip install -r requirements.txt
pytest -q
```

## Stato tecnico
- Test backend: 29 test superati nel pacchetto v10.
- La compilazione Next.js e l'avvio Docker vanno verificati nel tuo ambiente Linux/Chromebook.
- Il vecchio pipeline runner EuroLeague resta nel codice come test storico/contratto interno, ma non è più schedulato dal worker. Se usi un volume PostgreSQL già esistente dalla versione precedente, applica manualmente `infra/postgres/migrations/003_italian_competitions.sql` (non eliminare il volume per forzare il seed).

## v11 — NBA + LBA, primo collegamento a fonti reali

La base v10 è stata estesa senza eliminare il progetto italiano precedente:
- `GET /api/v1/live/nba/scoreboard` legge il calendario/punteggi dal JSON pubblico ESPN (senza chiave API). Supporta `?date=YYYYMMDD`.
- `GET /api/v1/live/lba/imported` espone le righe CSV realmente importate da BasketballScrapeR, senza inventare dati quando la cartella è vuota.
- `GET /api/v1/providers` dichiara esplicitamente lo stato dei connettori.
- `scripts_import_basketballscraper.sh [YYYY-YYYY]` clona lo scraper, tenta l'installazione delle dipendenze e scarica una stagione LBA in CSV.

Esempio locale per import LBA:
```bash
./scripts_import_basketballscraper.sh 2025-2026
export BASKETBALLSCRAPER_DATA_DIR=./data/basketballscraper
cd apps/api && uvicorn app.main:app --reload
```

**Limite importante:** questo è il primo strato d'ingestione, non ancora la sostituzione completa delle statistiche demo. Le API legacy `leaderboards`, profili e shot-chart sono ancora marcate `SYNTHETIC_DEMO`; i CSV dello scraper hanno schemi diversi e vanno normalizzati prima di poterli usare per statistiche avanzate coerenti. ESPN scoreboard è una fonte pubblica non ufficiale e può cambiare schema. NBA player stats/advanced stats e box score dettagliati richiedono un adattatore ulteriore.

### Riferimenti
- EL StatsLab: https://github.com/el-statslab/elstatslab-app
- BasketballScrapeR (supporta LBA; CSV BigDataBall; il README avverte che il play-by-play storico può essere incompleto): https://github.com/francescoolivo/BasketballScrapeR
- ESPN scoreboard JSON: https://site.api.espn.com/apis/site/v2/sports/basketball/nba/scoreboard


## v11.1 — affidabilità dei dati live
- Le risposte NBA live, LBA import e stato connettori ora inviano `Cache-Control: no-store`, evitando che punteggi o stato import restino congelati nella cache per 24 ore.
- Docker monta `./data/basketballscraper` in sola lettura nell'API, così i CSV scaricati dallo script sul computer host sono visibili anche al container.
- Aggiunto un test automatico per il contratto anti-cache degli endpoint live.

Nota: questo aggiornamento non trasforma ancora i CSV LBA in leaderboard normalizzate e non rende reali le fixture demo delle statistiche avanzate.


## v11.2 — diagnosi import LBA
- Aggiunto `GET /api/v1/live/lba/summary`, che riepiloga file CSV, righe e colonne senza interpretare erroneamente schemi sconosciuti come statistiche canoniche.
- La dashboard mostra l'inventario dei CSV LBA quando viene selezionato il campionato, separando chiaramente dati grezzi importati dalle leaderboard ancora dimostrative.
- Aggiunto test automatico del riepilogo import LBA.
- Verifica backend: 34 test superati.
- La compilazione frontend e l'avvio Docker completo restano da verificare in un ambiente con dipendenze installate e Docker.

### Aggiornamento stagione corrente (v11.3)
La dashboard aggiorna automaticamente il calendario/punteggi NBA ogni 60 secondi e permette l’aggiornamento manuale. Il controllo dell’inventario CSV LBA avviene ogni 5 minuti. Il progetto non esegue backfill delle stagioni passate. Attenzione: questo aggiornamento rende più fresco il scoreboard, ma non trasforma ancora le statistiche demo in dati reali; per quello occorre completare l’importazione e la normalizzazione dei box score.


### v11.4 — focus sulla stagione corrente e prima normalizzazione LBA
- Lo script di importazione usa ora per default la stagione LBA 2026-2027 e salva i file in una cartella dedicata alla stagione, senza backfill storico.
- Gli endpoint inventario leggono anche le sottocartelle stagionali.
- Nuovo endpoint `GET /api/v1/live/lba/analytics`: riconosce sia righe per-partita sia il formato Pbox aggregato di BasketballScrapeR (`GP`, `PTS`, `P2M/P2A`, `P3M/P3A`, `OREB/DREB`, `AST`, ecc.). Per Pbox, l'upstream documenta che sono totali stagionali aggregati per giocatore: le medie vengono calcolate dividendo per `GP`.
- L'inventario CSV ora cerca anche nelle sottocartelle prodotte dallo scraper (`LBA/2627/Pbox.csv`, `Tbox.csv`, `Obox.csv`).
- I CSV a riga stagionale con granularità ambigua restano visibili come dati grezzi; i totali Pbox sono invece normalizzati perché la semantica di `GP` e delle colonne è documentata dal progetto sorgente. I file esplicitamente appartenenti a stagioni precedenti vengono ignorati.
- La dashboard mostra anche i riepiloghi stagione Pbox reali, non solo CSV per-partita.
- Test backend: 41 test superati in locale.

Nota: per visualizzare i primi tre turni effettivi, occorre eseguire lo scraper sul computer connesso a Internet e verificare che produca box score riconoscibili. Il codice non inventa i tabellini mancanti.


### v11.6 — NBA box score
- `GET /api/v1/live/nba/boxscore/{event_id}` legge le statistiche giocatore da ESPN per una partita presente nel calendario.
- Nella dashboard NBA seleziona una riga partita per aprire il tabellino. La fonte ESPN è pubblica ma non ufficiale e può cambiare formato.
- Test backend aggiornati: 43 passati.
- Non è stato possibile verificare l'endpoint contro internet o eseguire la build frontend in questo ambiente.

## Verificare l'import LBA prima di usare i dati

Dopo aver eseguito lo scraper della sola stagione corrente, controlla i file importati con:

```bash
python scripts/validate_lba_import.py --data-dir ./data/basketballscraper/2026-2027
```

Per salvare anche il report JSON:

```bash
python scripts/validate_lba_import.py \
  --data-dir ./data/basketballscraper/2026-2027 \
  --output ./reports/lba-import-2026-27.json
```

Il comando non scarica dati e non inventa risultati. Restituisce codice `0` se trova statistiche riconoscibili della stagione corrente, `2` se mancano file o lo schema non è riconosciuto. Anche con codice `0`, il report indica `publication_ready: false`: prima di pubblicare classifica o risultati occorre verificare la corrispondenza con la fonte originale.


## v12.0 — risultati e classifica LBA

La dashboard LBA ora mostra la classifica calcolata da `data/lba/results_2026-27.csv`. L'import contiene 24 risultati delle giornate 1–3; ogni riga include URL e tipo della fonte. Le giornate 1–2 sono documentate con riepiloghi secondari e la giornata 3 con il calendario LBA. Questo è uno snapshot curato, non un feed live.

Endpoint: `GET /api/v1/live/lba/results` e `GET /api/v1/live/lba/standings`. Per vedere le partite: `curl http://localhost:8000/api/v1/live/lba/results`; per la classifica: `curl http://localhost:8000/api/v1/live/lba/standings`.

La classifica non usa i dati demo dei giocatori: viene ricalcolata dalle partite concluse. Restano da implementare l'aggiornamento automatico dalle fonti, il confronto finale di tutti i risultati con LBA e i box score verificati per statistiche individuali.

## v12.0 — aggiornamento automatico dei risultati
Il worker Celery aggiorna il tabellone NBA per ieri e oggi nel fuso `America/New_York` ogni 6 ore e tenta di importare i risultati LBA ogni 3 ore. I tabellini CSV LBA sono aggiornati ogni notte tramite BasketballScrapeR. Redis e Celery Beat devono essere in esecuzione perché le pianificazioni partano.

- Stato ultimo aggiornamento: `GET /api/v1/refresh/status`
- Risultati LBA importati: `GET /api/v1/live/lba/results`
- Classifica LBA ricalcolata: `GET /api/v1/live/lba/standings`
- Tabellone NBA live: `GET /api/v1/live/nba/scoreboard?date=YYYYMMDD`

Il worker condivide ora il volume `data/lba` con l'API: in precedenza un CSV aggiornato nel container worker poteva non essere visibile alla dashboard. I risultati importati mantengono la provenienza e lo snapshot precedente viene conservato se l'import fallisce.

**Nota di verifica:** i test usano risposte simulate per coprire parsing, validazione e sostituzione atomica; non dimostrano da soli che le fonti esterne siano raggiungibili o che il parser HTML LBA funzioni contro ogni aggiornamento del sito. Dopo la pubblicazione, controllare `/api/v1/refresh/status` e confrontare le partite con la fonte originale.


## NBA Analytics Lab 26/27 — aggiornamento 31 ottobre 2026

Il refresh NBA salva ora i box score ESPN delle partite concluse nella stagione corrente e l'API aggrega le metriche avanzate dei giocatori sui tabellini effettivamente acquisiti. Endpoint: `GET /api/v1/live/nba/players/advanced`. La copertura è espressa in partite archiviate; non vengono riempiti i dati mancanti con valori dimostrativi. Il job programmato è alle 08:00 `Europe/Rome` (richiede worker e Celery Beat attivi).
