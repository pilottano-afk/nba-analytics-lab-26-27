CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE TABLE IF NOT EXISTS competitions(id TEXT PRIMARY KEY,code VARCHAR(10),name TEXT,season VARCHAR(10));
CREATE TABLE IF NOT EXISTS teams(id TEXT PRIMARY KEY,name TEXT,short_code VARCHAR(10));
CREATE TABLE IF NOT EXISTS players(id TEXT PRIMARY KEY,full_name TEXT,primary_position VARCHAR(10),birth_year INT,height_cm NUMERIC);
CREATE TABLE IF NOT EXISTS games(id TEXT PRIMARY KEY,competition_id TEXT REFERENCES competitions(id),home_team_id TEXT REFERENCES teams(id),away_team_id TEXT REFERENCES teams(id),game_date DATE,home_score INT,away_score INT,status VARCHAR(20));
CREATE TABLE IF NOT EXISTS shot_events(id TEXT PRIMARY KEY,game_id TEXT REFERENCES games(id),player_id TEXT REFERENCES players(id),team_id TEXT REFERENCES teams(id),period INT,clock_seconds_remaining INT,x_coord NUMERIC,y_coord NUMERIC,zone_id VARCHAR(40),is_made BOOLEAN,is_clutch BOOLEAN,shot_distance_m NUMERIC);
CREATE TABLE IF NOT EXISTS lineup_stints(id TEXT PRIMARY KEY,game_id TEXT REFERENCES games(id),team_id TEXT REFERENCES teams(id),lineup_hash TEXT,player_ids TEXT[],duration_seconds INT,possessions NUMERIC,points_for INT,points_opp INT);
CREATE INDEX IF NOT EXISTS shot_player_game_zone_idx ON shot_events(player_id,game_id,zone_id);
CREATE INDEX IF NOT EXISTS players_name_trgm_idx ON players USING gin(full_name gin_trgm_ops);
CREATE TABLE IF NOT EXISTS raw_game_payloads(id BIGSERIAL PRIMARY KEY,competition_id TEXT,game_id TEXT,payload JSONB,ingested_at TIMESTAMPTZ DEFAULT now(), checksum TEXT NOT NULL, UNIQUE(competition_id,game_id,checksum));
CREATE TABLE IF NOT EXISTS quarantined_games(id BIGSERIAL PRIMARY KEY,game_id TEXT,errors JSONB,created_at TIMESTAMPTZ DEFAULT now());

-- v5 analytical snapshot layer
CREATE TABLE IF NOT EXISTS analytical_snapshots(
  version VARCHAR(32) PRIMARY KEY,
  competition_id TEXT NOT NULL,
  status VARCHAR(20) NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  game_count INT NOT NULL DEFAULT 0,
  verified_game_count INT NOT NULL DEFAULT 0,
  checksum TEXT
);
CREATE TABLE IF NOT EXISTS team_game_analytics(
  snapshot_version VARCHAR(32) REFERENCES analytical_snapshots(version),
  game_id TEXT REFERENCES games(id),
  team_id TEXT REFERENCES teams(id),
  points INT,
  possessions NUMERIC,
  ortg NUMERIC,
  ts_pct NUMERIC,
  efg_pct NUMERIC,
  ftr NUMERIC,
  PRIMARY KEY(snapshot_version, game_id, team_id)
);
CREATE INDEX IF NOT EXISTS team_game_analytics_team_idx ON team_game_analytics(team_id, snapshot_version);
