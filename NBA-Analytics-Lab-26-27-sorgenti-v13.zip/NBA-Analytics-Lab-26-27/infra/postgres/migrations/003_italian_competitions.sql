-- Idempotent migration for databases created by the previous Euro Basketball Stats Hub prototype.
-- Run manually against an existing database; docker-entrypoint-initdb only runs on a fresh volume.
INSERT INTO competitions(id, code, name, season) VALUES
  ('lba-2026-27', 'LBA', 'Serie A LBA', '2026/27'),
  ('a2-2026-27', 'A2', 'Serie A2 Old Wild West', '2026/27')
ON CONFLICT (id) DO NOTHING;
INSERT INTO teams(id, name, short_code) VALUES
  ('lba-udine', 'APU Old Wild West Udine', 'UDN'),
  ('lba-milano', 'EA7 Emporio Armani Milano', 'MIL'),
  ('lba-bologna', 'Virtus Bologna', 'VBO'),
  ('lba-venezia', 'Umana Reyer Venezia', 'VEN'),
  ('a2-fortitudo', 'Fortitudo Bologna', 'FBO'),
  ('a2-rimini', 'Dole Basket Rimini', 'RIM'),
  ('a2-brindisi', 'Valtur Brindisi', 'BRI'),
  ('a2-livorno', 'Libertas Livorno', 'LIV')
ON CONFLICT (id) DO NOTHING;
