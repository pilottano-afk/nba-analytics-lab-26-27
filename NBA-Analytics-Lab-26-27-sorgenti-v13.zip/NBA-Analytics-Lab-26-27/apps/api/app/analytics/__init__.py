"""Pure, deterministic basketball analytics."""
