"""EuroLeague ingestion pipeline primitives."""
