import "./globals.css";import Link from "next/link";
export const metadata={title:"Italian Basketball Analytics",description:"Statistiche e analisi per Serie A LBA e Serie A2 italiana — stagione 2026/27"};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="it"><body><header className="topbar"><Link href="/" className="brand">ITALIA<span>HOOPS</span></Link><nav><Link href="/">Dashboard</Link><Link href="/studio">Shot Studio</Link></nav><small>2026/27 · <b>● PROTOTIPO</b></small></header>{children}</body></html>}
